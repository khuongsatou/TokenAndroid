package com.example.da_traloicauhoi.Ultils.Intergface;

import android.content.Context;

import org.json.JSONException;
import org.json.JSONObject;

public interface XuLyJSON {
    void XuLy(JSONObject jsonObject, Context context) throws JSONException;
}
